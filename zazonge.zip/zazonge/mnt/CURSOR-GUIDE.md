# 🖱️ 自定义光标效果详解

## 设计理念

光标效果的设计灵感来自于现代网页设计趋势，同时融入了大正浪漫的优雅美学。通过双层光标系统（点 + 轮廓）和点击涟漪效果，营造出一种精致、流动的交互体验。

## 技术实现

### 1. 光标点 (Cursor Dot)

```javascript
// 立即跟随鼠标位置
document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    cursorDot.style.left = mouseX + 'px';
    cursorDot.style.top = mouseY + 'px';
});
```

**特点**：
- 8x8px 小圆点
- 固定定位 (position: fixed)
- transform: translate(-50%, -50%) 居中
- mix-blend-mode: difference 混合模式
- 悬停时扩大到 16x16px

### 2. 光标轮廓 (Cursor Outline)

```javascript
// 延迟跟随效果 (缓动动画)
function animateOutline() {
    outlineX += (mouseX - outlineX) * 0.15;
    outlineY += (mouseY - outlineY) * 0.15;
    
    cursorOutline.style.left = outlineX + 'px';
    cursorOutline.style.top = outlineY + 'px';
    
    requestAnimationFrame(animateOutline);
}
```

**特点**：
- 40x40px 圆形边框
- 使用 requestAnimationFrame 实现平滑动画
- 缓动系数 0.15 创造跟随感
- 悬停时扩大到 60x60px
- 半透明效果 (opacity: 0.5)

### 3. 点击涟漪效果

```javascript
document.addEventListener('click', (e) => {
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    ripple.style.left = e.clientX + 'px';
    ripple.style.top = e.clientY + 'px';
    ripple.style.transform = 'translate(-50%, -50%)';
    
    document.body.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
});
```

**动画**：
```css
@keyframes ripple-animation {
    0% {
        width: 0;
        height: 0;
        opacity: 0.8;
    }
    100% {
        width: 80px;
        height: 80px;
        opacity: 0;
    }
}
```

### 4. 悬停交互

```javascript
const hoverElements = document.querySelectorAll('a, button, .post');

hoverElements.forEach(element => {
    element.addEventListener('mouseenter', () => {
        cursorDot.classList.add('hover');
        cursorOutline.classList.add('hover');
    });
    
    element.addEventListener('mouseleave', () => {
        cursorDot.classList.remove('hover');
        cursorOutline.classList.remove('hover');
    });
});
```

## 视觉效果

### 正常状态
```
光标点：    8x8px  | 古铜金色 (#c89b6d)
光标轮廓：  40x40px | 古铜金边框，半透明
```

### 悬停状态
```
光标点：    16x16px | 深古铜金色 (#a67c52)
光标轮廓：  60x60px  | 古铜金边框，增强透明度
```

### 点击瞬间
```
涟漪：从 0 扩散到 80px
持续：0.6秒
颜色：古铜金边框
效果：淡出消失
```

## 性能优化

### 1. 使用 requestAnimationFrame
- 替代 setInterval/setTimeout
- 与浏览器刷新率同步 (60fps)
- 自动暂停非活动标签页

### 2. CSS 硬件加速
```css
.cursor-dot, .cursor-outline {
    transform: translate(-50%, -50%);  /* 触发GPU加速 */
    will-change: left, top;            /* 提示浏览器优化 */
}
```

### 3. 事件节流
- mousemove 直接更新位置
- 轮廓通过 RAF 循环更新，自然节流

### 4. DOM 优化
- 涟漪元素用完即删除
- 避免内存泄漏

## 兼容性处理

### 隐藏系统光标
```css
* {
    cursor: none;  /* 全局隐藏系统光标 */
}
```

### 鼠标进出检测
```javascript
document.addEventListener('mouseleave', () => {
    cursorDot.style.opacity = '0';
    cursorOutline.style.opacity = '0';
});

document.addEventListener('mouseenter', () => {
    cursorDot.style.opacity = '1';
    cursorOutline.style.opacity = '0.5';
});
```

## 配色方案

### 浅色模式
```css
--cursor-color: #c89b6d;  /* 古铜金 */
```

### 深色模式
```css
--cursor-color: #d4a574;  /* 更亮的古铜金 */
```

## 交互元素列表

光标会对以下元素产生悬停效果：
- ✅ 所有链接 (`<a>`)
- ✅ 所有按钮 (`<button>`)
- ✅ 文章卡片 (`.post`)

## 自定义建议

### 修改光标大小
```css
.cursor-dot { width: 10px; height: 10px; }
.cursor-outline { width: 50px; height: 50px; }
```

### 修改跟随速度
```javascript
// 更慢：0.1  |  更快：0.3
outlineX += (mouseX - outlineX) * 0.15;
```

### 修改涟漪大小
```css
@keyframes ripple-animation {
    100% {
        width: 100px;   /* 改为更大 */
        height: 100px;
    }
}
```

### 修改颜色
```css
:root {
    --cursor-color: #你的颜色;
}
```

## 移动端处理

**重要提示**：触摸设备不支持自定义光标，但 `cursor: none` 不会影响触摸操作。移动端用户会看到正常的触摸交互，无需额外处理。

## 浏览器支持

| 浏览器 | 版本 | 支持度 |
|--------|------|--------|
| Chrome | 88+ | ✅ 完美 |
| Firefox | 85+ | ✅ 完美 |
| Safari | 14+ | ✅ 完美 |
| Edge | 88+ | ✅ 完美 |

## 已知问题

### 1. 文本选择
- mix-blend-mode 可能影响文本选择
- 解决：选择时光标会自动适应

### 2. iframe 内部
- 自定义光标在 iframe 内不生效
- 这是浏览器安全限制

### 3. 某些输入框
- 部分输入框可能需要显示系统光标
- 可针对性添加 `cursor: text` 覆盖

## 灵感来源

- **Awwwards** - 现代网页设计趋势
- **大正浪漫** - 优雅的古典美学
- **蒸汽朋克** - 机械与艺术的融合
- **Prima Doll** - 温暖而精致的视觉语言

## 最佳实践

1. ✅ 保持光标大小适中，不要过大遮挡内容
2. ✅ 使用与主题一致的配色
3. ✅ 确保悬停效果明显但不夸张
4. ✅ 动画流畅自然，避免卡顿
5. ✅ 涟漪效果短暂精致，不干扰阅读

---

这个光标系统是为 Podevus 博客量身定制的，完美融入了大正浪漫的整体设计风格。每一个细节都经过精心调校，既保持了现代感，又不失古典优雅。
