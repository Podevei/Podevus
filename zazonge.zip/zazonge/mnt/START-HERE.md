# 🚀 开始使用 Podevus 博客

## 快速开始

### 方法1: 在浏览器中打开
1. 找到 `index-enhanced.html` 文件
2. 双击打开,或拖入浏览器
3. 开始浏览你的博客!

### 方法2: 使用本地服务器
```bash
# 进入Blog目录
cd Blog

# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000

# 然后访问 http://localhost:8000
```

---

## 📂 文件说明

### 🏠 主页面
- **index-enhanced.html** - 首页,展示最新文章
- **about-enhanced.html** - 关于页面
- **blog.html** - 所有文章列表

### 📁 分类页面 (category/)
- **tech.html** - 技术分类
- **reading.html** - 读书分类
- **anime.html** - 幻想分类
- **thinking.html** - 思考分类

### 📝 文章页面 (posts/)
- **prima-doll-enhanced.html** - Prima Doll完整文章
- **sample-post-1.html** - 技术文章模板
- **sample-post-2.html** - 读书笔记模板

### 📚 文档
- **README.md** - 完整功能说明
- **CURSOR-EFFECTS.md** - 光标效果详解
- **FILE-LIST.md** - 文件清单

---

## ✨ 特色功能

### 🖱️ 自定义光标
在桌面设备上移动鼠标,你会看到:
- 双层光标跟随效果
- 悬停在链接上的放大效果
- 点击时的涟漪动画

**在触摸设备上自动禁用,保持原生体验**

### 🎨 大正浪漫设计
- 温暖的古铜金配色
- 优雅的衬线字体
- 精致的卡片悬停效果
- 平滑的过渡动画

### 🌙 自动深色模式
根据系统设置自动切换浅色/深色主题

### 📱 完全响应式
在手机、平板、电脑上都有完美体验

---

## 🎯 下一步

### 添加你的第一篇文章
1. 复制 `posts/sample-post-1.html`
2. 重命名为 `posts/my-first-post.html`
3. 编辑内容:
   - 修改 `<title>` 标签
   - 修改 `.article-title` 中的标题
   - 修改 `.post-category` 中的分类
   - 修改 `.article-content` 中的正文
4. 在 `index-enhanced.html` 中添加文章卡片

### 自定义配色
在任意HTML文件中找到 `:root` 选择器:
```css
:root {
    --primary-bg: #faf8f3;      /* 背景色 */
    --accent-color: #c89b6d;    /* 强调色 */
    --text-primary: #2d2520;    /* 文字色 */
}
```
修改这些值即可改变整体配色!

### 调整光标效果
参考 `CURSOR-EFFECTS.md` 了解详细的自定义选项

---

## 💡 使用技巧

### 预览效果
- **首页**: 从 `index-enhanced.html` 开始
- **光标**: 在链接和卡片上移动鼠标
- **深色**: 切换系统深色模式查看效果
- **响应式**: 调整浏览器窗口大小

### 发布博客
将整个 `Blog/` 文件夹上传到:
- GitHub Pages
- Netlify
- Vercel
- 任何静态网站托管服务

### 性能优化
文件已经优化过,无需额外处理:
- ✅ CSS和JS内联(减少HTTP请求)
- ✅ 使用CSS变量(便于维护)
- ✅ GPU加速动画(transform)
- ✅ 响应式图片(未使用图片)

---

## 🐛 常见问题

### Q: 光标效果不显示?
A: 确保:
1. 在桌面浏览器中打开(非触摸设备)
2. JavaScript已启用
3. 浏览器支持现代CSS(Chrome/Firefox/Safari/Edge)

### Q: 如何禁用光标效果?
A: 在HTML中删除:
1. `cursor: none !important;` 样式
2. 光标相关的CSS(.cursor-dot, .cursor-outline等)
3. 光标相关的JavaScript代码

### Q: 深色模式不切换?
A: 深色模式跟随系统设置:
- Mac: 系统偏好设置 → 通用 → 外观
- Windows: 设置 → 个性化 → 颜色
- 或使用浏览器的开发者工具强制切换

### Q: 移动端看起来不一样?
A: 这是正常的!移动端:
- 自动禁用光标效果
- 使用触摸友好的布局
- 调整字体大小和间距

---

## 📖 学习资源

### 想了解更多?
- **README.md** - 完整项目文档
- **CURSOR-EFFECTS.md** - 光标系统详解
- **FILE-LIST.md** - 所有文件清单

### 修改建议
- 从简单的文字修改开始
- 逐步调整颜色和样式
- 参考现有代码的结构
- 保存备份再做大改动

---

## 🎉 享受你的博客!

这个博客已经包含了:
- ✅ 10个完整的HTML页面
- ✅ 统一的大正浪漫设计
- ✅ 精致的光标交互系统
- ✅ 完整的响应式支持
- ✅ 自动深色模式
- ✅ 触摸设备优化

**现在就打开 `index-enhanced.html` 开始你的博客之旅吧!** ✨

---

## 📞 需要帮助?

如果你:
- 想添加新功能
- 遇到显示问题
- 需要自定义建议

参考 `README.md` 中的详细说明,或查看 `CURSOR-EFFECTS.md` 了解光标系统!

---

**祝你写作愉快!** 📝✨

© 2025 Podevus | 择美而留,存质而弃暗
