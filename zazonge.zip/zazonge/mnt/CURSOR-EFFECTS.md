# 🖱️ 光标效果系统说明

## 效果演示

每个页面都包含以下光标效果:

### 1. 双层光标系统

```
┌─────────────────────────────────┐
│                                 │
│     ○ ← 空心轮廓 (40px)        │
│    ●  ← 实心圆点 (8px)         │
│                                 │
│  圆点即时跟随,轮廓延迟跟随     │
│  创造优雅的跟随效果             │
└─────────────────────────────────┘
```

**实现原理:**
- **圆点**: 直接跟随鼠标位置
- **轮廓**: 使用缓动算法延迟跟随
- **混合模式**: `mix-blend-mode: difference` 创造独特效果

### 2. 悬停交互

当鼠标悬停在可交互元素上时:

```
普通状态:           悬停状态:
  ○                   ⊙
 ●                   ●●

圆点放大 1.5倍      轮廓扩展至 60px
颜色变为强调色      透明度降低
```

**触发元素:**
- 所有链接 (`<a>`)
- 所有按钮 (`<button>`)
- 文章卡片 (`.post`)

### 3. 点击涟漪效果

每次点击时产生扩散涟漪:

```
点击瞬间    0.2秒后    0.4秒后    0.6秒后
   ○          ◯          ⊙          (消失)
  20px      40px       70px       100px
 100%       60%        20%         0%
```

**动画参数:**
- 起始大小: 20px
- 结束大小: 100px
- 持续时间: 0.6秒
- 缓动函数: ease-out

## 技术实现

### HTML 结构

```html
<body>
    <!-- 光标元素 -->
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>
    
    <!-- 页面内容 -->
    ...
</body>
```

### CSS 样式

```css
/* 隐藏默认光标 */
* {
    cursor: none !important;
}

/* 光标圆点 */
.cursor-dot {
    width: 8px;
    height: 8px;
    background: var(--accent-color);
    border-radius: 50%;
    position: fixed;
    top: 0;
    left: 0;
    pointer-events: none;
    z-index: 10000;
    mix-blend-mode: difference;
}

/* 光标轮廓 */
.cursor-outline {
    width: 40px;
    height: 40px;
    border: 2px solid var(--accent-color);
    border-radius: 50%;
    position: fixed;
    top: 0;
    left: 0;
    pointer-events: none;
    z-index: 9999;
    opacity: 0.5;
}

/* 悬停状态 */
.cursor-dot.expand {
    transform: translate(-50%, -50%) scale(1.5);
}

.cursor-outline.expand {
    width: 60px;
    height: 60px;
    opacity: 0.3;
}
```

### JavaScript 逻辑

```javascript
// 1. 获取光标元素
const cursorDot = document.querySelector('.cursor-dot');
const cursorOutline = document.querySelector('.cursor-outline');

// 2. 跟踪鼠标位置
let mouseX = 0, mouseY = 0;
let outlineX = 0, outlineY = 0;

// 3. 圆点即时跟随
document.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    cursorDot.style.left = mouseX + 'px';
    cursorDot.style.top = mouseY + 'px';
});

// 4. 轮廓延迟跟随 (缓动动画)
function animateOutline() {
    const delay = 0.15;
    outlineX += (mouseX - outlineX) * delay;
    outlineY += (mouseY - outlineY) * delay;
    
    cursorOutline.style.left = outlineX + 'px';
    cursorOutline.style.top = outlineY + 'px';
    
    requestAnimationFrame(animateOutline);
}
animateOutline();

// 5. 悬停交互
const interactiveElements = document.querySelectorAll('a, button, .post');
interactiveElements.forEach(el => {
    el.addEventListener('mouseenter', () => {
        cursorDot.classList.add('expand');
        cursorOutline.classList.add('expand');
    });
    el.addEventListener('mouseleave', () => {
        cursorDot.classList.remove('expand');
        cursorOutline.classList.remove('expand');
    });
});

// 6. 点击涟漪
document.addEventListener('click', (e) => {
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    ripple.style.left = (e.clientX - 10) + 'px';
    ripple.style.top = (e.clientY - 10) + 'px';
    document.body.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
});

// 7. 触摸设备处理
if ('ontouchstart' in window) {
    cursorDot.style.display = 'none';
    cursorOutline.style.display = 'none';
    document.body.style.cursor = 'auto';
}
```

## 性能优化

### 1. GPU 加速
- 使用 `transform` 而非 `top/left` 移动元素
- 使用 `translate3d` 触发硬件加速

### 2. 动画优化
- `requestAnimationFrame` 同步浏览器刷新率
- 缓动算法减少计算量
- 固定的延迟系数 (0.15)

### 3. 事件优化
- 使用事件委托减少监听器数量
- `pointer-events: none` 避免光标干扰交互

### 4. 内存管理
- 涟漪元素在动画结束后自动移除
- 不创建不必要的DOM节点

## 兼容性处理

### 桌面设备
- ✅ 显示自定义光标
- ✅ 完整交互效果
- ✅ 所有动画

### 触摸设备
- ✅ 自动检测触摸支持
- ✅ 禁用自定义光标
- ✅ 恢复原生光标
- ✅ 保持其他功能

### 检测代码
```javascript
if ('ontouchstart' in window) {
    // 触摸设备,禁用自定义光标
    cursorDot.style.display = 'none';
    cursorOutline.style.display = 'none';
    document.body.style.cursor = 'auto';
}
```

## 自定义选项

### 修改光标颜色
```css
:root {
    --accent-color: #你的颜色;
}
```

### 修改光标大小
```css
.cursor-dot {
    width: 10px;   /* 默认 8px */
    height: 10px;
}

.cursor-outline {
    width: 50px;   /* 默认 40px */
    height: 50px;
}
```

### 修改跟随速度
```javascript
const delay = 0.15;  // 0.1-0.3 之间调整
                     // 数值越小,跟随越快
```

### 修改涟漪效果
```css
@keyframes ripple-animation {
    from {
        width: 30px;    /* 起始大小 */
        height: 30px;
        opacity: 1;
    }
    to {
        width: 120px;   /* 结束大小 */
        height: 120px;
        opacity: 0;
    }
}
```

## 用户体验考虑

### 优点
✅ 增强品牌识别度
✅ 提升交互反馈
✅ 现代化视觉效果
✅ 引导用户注意力

### 注意事项
⚠️ 不影响可访问性
⚠️ 不干扰原生功能
⚠️ 触摸设备自动禁用
⚠️ 性能开销可控

## 浏览器支持

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ 所有现代移动浏览器

## 常见问题

**Q: 为什么在某些元素上光标不变化?**
A: 需要将元素添加到 `interactiveElements` 选择器中:
```javascript
const interactiveElements = document.querySelectorAll('a, button, .your-class');
```

**Q: 如何完全禁用光标效果?**
A: 删除以下部分:
1. 光标相关的 CSS 样式
2. `<div class="cursor-dot">` 和 `<div class="cursor-outline">` 元素
3. 光标相关的 JavaScript 代码
4. `cursor: none !important;` 样式规则

**Q: 光标延迟太明显怎么办?**
A: 增加 `delay` 值,例如从 `0.15` 改为 `0.25`:
```javascript
const delay = 0.25;  // 更明显的延迟效果
```

**Q: 在暗色背景上光标不明显?**
A: 调整混合模式或颜色:
```css
.cursor-dot {
    mix-blend-mode: difference;  /* 或改为 normal */
    background: #ffffff;          /* 使用白色 */
}
```

---

## 效果总结

这个光标系统为博客添加了:
- 🎨 独特的视觉识别
- ✨ 精致的交互反馈
- 🖱️ 现代化的用户体验
- 📱 智能的设备适配

完美契合大正浪漫的优雅主题! 🌸
